function validateForm() {
	var name = document.forms["myForm"]["name"].value;
	var email = document.forms["myForm"]["mail"].value;
	var interest = document.forms["myForm"]["interest"];

	if (name == "") {
		alert("Name must be filled out");
		return false;
	}
	if (name.length>30){
		alert("Full name must not exceed 30 characters in length.");
		return false;
	}
	if (!isNaN(name)){
		alert("Full name must not include numeric characters.");
		return false;
	}
	if (mail == "") {
		alert("Email must be filled out");
		return false;
	}
	if (interest.checked == false ) {
		alert("Your interests must be filled out");
		return false;
	}

}
